#
# Tkinter 3000
#
# a simple model/view/controller example
#

from WCK import Widget, Controller, Observable, bind
from WCK import FOREGROUND, FONT # platform default

class MyModel(Observable):

    def __init__(self):
        self.count = 0

    def increment(self):
        self.count += 1
        self.notify(None) # notify observers

class MyController(Controller):

    @bind("<ButtonRelease-1>")
    def handle_button_release_1(self, event):
        # update the model
        model = event.widget.model
        if model:
            model.increment()

class MyView(Widget):

    model = None
    ui_controller = MyController

    def _notify(self, event, data):
        # called by the model
        self.ui_damage() # update myself

    def setmodel(self, model):
        # install new model
        assert isinstance(model, Observable)
        if self.model:
            self.model.removeobserver(self._notify)
        self.model = model
        self.model.addobserver(self._notify)

    def ui_handle_repair(self, draw, x0, y0, x1, y1):
        # repair widget contents
        if not self.model:
            return
        font = self.ui_font(FOREGROUND, FONT)
        text = str(self.model.count)
        draw.text((10, 10), text, font)

    def ui_handle_destroy(self):
        # cleanup
        if self.model:
            self.model.removeobserver(self._notify)

if __name__ == "__main__":
    # try it out

    from Tkinter import Tk

    root = Tk()

    model = MyModel()

    view = MyView(root, background="light blue")
    view.pack(side="left")

    view.setmodel(model)

    another_view = MyView(root, background="light yellow")
    another_view.pack(side="left")

    another_view.setmodel(model) # shares the same model!

    def tick():
        model.increment()
        root.after(1000, tick)

    tick() # start ticking

    root.mainloop()
