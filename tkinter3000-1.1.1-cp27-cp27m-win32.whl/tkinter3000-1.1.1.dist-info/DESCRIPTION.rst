The Widget Construction Kit (WCK) is an extension API that allows
you to implement all sorts of custom widgets, in pure Python.  This
library provides a WCK implementation for Tkinter.


